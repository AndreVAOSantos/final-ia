def executar():
    print("Iniciando Pouso")
