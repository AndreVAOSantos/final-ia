import unittest
import assistente

DECOLAGEM = "audios/decolagem.wav"
ESTAGIO1 = "audios/estagio1.wav"
ESTAGIO2 = "audios/estagio2.wav"
POUSO = "audios/pouso.wav"
SATELITE = "audios/satelite.wav"

class TesteAssistente(unittest.TestCase):
    def test_decolagem(self):
        transcricao = assistente.reconhecer_comando(DECOLAGEM)
        self.assertIsNotNone(transcricao)
        comando = assistente.processar_comando_texto(transcricao)
        self.assertEqual(comando, "decolagem")
    
    def test_estagio1(self):
        transcricao = assistente.reconhecer_comando(ESTAGIO1)
        self.assertIsNotNone(transcricao)
        comando = assistente.processar_comando_texto(transcricao)
        self.assertEqual(comando, "estagio_1")
    
    def test_estagio2(self):
        transcricao = assistente.reconhecer_comando(ESTAGIO2)
        self.assertIsNotNone(transcricao)
        comando = assistente.processar_comando_texto(transcricao)
        self.assertEqual(comando, "estagio_2")
    
    def test_pouso(self):
        transcricao = assistente.reconhecer_comando(POUSO)
        self.assertIsNotNone(transcricao)
        comando = assistente.processar_comando_texto(transcricao)
        self.assertEqual(comando, "pouso")
    
    def test_satelite(self):
        transcricao = assistente.reconhecer_comando(SATELITE)
        self.assertIsNotNone(transcricao)
        comando = assistente.processar_comando_texto(transcricao)
        self.assertEqual(comando, "satelite")

if __name__ == "__main__":
    unittest.main()
