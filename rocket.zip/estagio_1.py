def executar():
    print("Iniciando Estágio 1")
