import json
import pyaudio
import wave
import time
from transformers import pipeline
import nltk
from nltk.tokenize import word_tokenize
import numpy as np

# Importação dos atuadores
import decolagem
import estagio_1
import estagio_2
import pouso
import satelite

# Baixar recursos do NLTK (caso não estejam presentes)
nltk.download('punkt')

# Carregar configuração externa de comandos
with open("config.json", "r", encoding="utf-8") as f:
    config = json.load(f)

# Inicializar pipeline de reconhecimento de fala (ASR) com modelo Hugging Face
# device=-1 garante que a CPU seja utilizada
asr_pipeline = pipeline("automatic-speech-recognition", model="openai/whisper-small", device=-1)

def record_audio(output_filename, record_seconds=5):
    """
    Grava áudio a partir do microfone e salva em um arquivo WAV.
    """
    chunk = 1024
    sample_format = pyaudio.paInt16  # 16 bits por amostra
    channels = 1
    fs = 16000  # Taxa de amostragem (16kHz, compatível com o modelo Whisper)
    
    p = pyaudio.PyAudio()
    stream = p.open(format=sample_format, channels=channels, rate=fs, frames_per_buffer=chunk, input=True)
    
    print("Gravando... Fale o comando!")
    frames = []
    for _ in range(0, int(fs / chunk * record_seconds)):
        data = stream.read(chunk)
        frames.append(data)
    
    stream.stop_stream()
    stream.close()
    p.terminate()
    print("Gravação finalizada.")
    
    wf = wave.open(output_filename, 'wb')
    wf.setnchannels(channels)
    wf.setsampwidth(p.get_sample_size(sample_format))
    wf.setframerate(fs)
    wf.writeframes(b''.join(frames))
    wf.close()

def load_audio_file(filename):
    """
    Carrega o arquivo WAV e retorna um array NumPy com o áudio e a taxa de amostragem.
    Essa função evita o uso do ffmpeg, lendo diretamente o arquivo.
    """
    with wave.open(filename, 'rb') as wf:
        sr = wf.getframerate()
        frames = wf.readframes(wf.getnframes())
        # Converter bytes para um array NumPy de inteiros (int16)
        audio_np = np.frombuffer(frames, dtype=np.int16)
        # Normalizar para float32 no intervalo [-1, 1]
        audio_float = audio_np.astype(np.float32) / 32768.0
    return audio_float, sr

def reconhecer_comando(audio_path):
    print("Carregando áudio e realizando transcrição...")
    audio, sr = load_audio_file(audio_path)
    # Passa o áudio e a taxa de amostragem em um dicionário
    resultado = asr_pipeline({"array": audio, "sampling_rate": sr})
    texto = resultado["text"]
    print("Transcrição:", texto)
    return texto


def processar_comando_texto(texto):
    """
    Tokeniza o texto reconhecido e verifica qual comando configurado está presente.
    A verificação exige que TODAS as palavras-chave definidas estejam presentes.
    """
    tokens = word_tokenize(texto.lower())
    for comando, palavras_chave in config["comandos"].items():
        if all(palavra in tokens for palavra in palavras_chave):
            return comando
    return None

def executar_acao(comando):
    """
    Chama o atuador correspondente ao comando.
    """
    if comando == "decolagem":
        decolagem.executar()
    elif comando == "estagio_1":
        estagio_1.executar()
    elif comando == "estagio_2":
        estagio_2.executar()
    elif comando == "pouso":
        pouso.executar()
    elif comando == "satelite":
        satelite.executar()
    else:
        print("Ação não encontrada para o comando informado.")

def main():
    # Certifique-se de que a pasta 'audios' exista no diretório do projeto
    audio_filename = "audios/comando.wav"
    record_audio(audio_filename, record_seconds=5)
    
    # Transcreve o áudio para texto
    comando_texto = reconhecer_comando(audio_filename)
    
    # Processa o texto e identifica o comando
    comando = processar_comando_texto(comando_texto)
    if comando:
        print(f"Executando ação: {comando}")
        executar_acao(comando)
    else:
        print("Nenhum comando válido foi identificado.")

if __name__ == "__main__":
    main()
