def executar():
    print("Iniciando Liberação do Satélite")
