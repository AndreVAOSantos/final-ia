import unittest
import io
import sys
import assistente

class TestAssistente(unittest.TestCase):
    def setUp(self):
        # Redireciona a saída padrão para capturar o que é impresso
        self.held_stdout = io.StringIO()
        self._original_stdout = sys.stdout
        sys.stdout = self.held_stdout

    def tearDown(self):
        # Restaura a saída padrão
        sys.stdout = self._original_stdout

    def _reset_stdout(self):
        # Limpa o buffer para cada teste
        self.held_stdout.truncate(0)
        self.held_stdout.seek(0)

    def test_decolagem(self):
        self._reset_stdout()
        texto = "Por favor, iniciar decolagem imediatamente"
        comando = assistente.processar_comando_texto(texto)
        # Exibe o comando identificado
        print("Comando identificado:", comando)
        assistente.executar_acao(comando)
        output = self.held_stdout.getvalue()
        print(output)  # Mostra a resposta no terminal
        self.assertIn("Iniciando Decolagem", output)
    
    def test_estagio_1(self):
        self._reset_stdout()
        texto = "Preciso iniciar estágio 1 da missão"
        comando = assistente.processar_comando_texto(texto)
        print("Comando identificado:", comando)
        assistente.executar_acao(comando)
        output = self.held_stdout.getvalue()
        print(output)
        self.assertIn("Iniciando Estágio 1", output)
    
    def test_estagio_2(self):
        self._reset_stdout()
        texto = "Vamos iniciar estágio 2 com cuidado"
        comando = assistente.processar_comando_texto(texto)
        print("Comando identificado:", comando)
        assistente.executar_acao(comando)
        output = self.held_stdout.getvalue()
        print(output)
        self.assertIn("Iniciando Estágio 2", output)
    
    def test_pouso(self):
        self._reset_stdout()
        texto = "Iniciar pouso imediatamente"
        comando = assistente.processar_comando_texto(texto)
        print("Comando identificado:", comando)
        assistente.executar_acao(comando)
        output = self.held_stdout.getvalue()
        print(output)
        self.assertIn("Iniciando Pouso", output)
    
    def test_satelite(self):
        self._reset_stdout()
        texto = "Por favor, iniciar liberação satélite agora"
        comando = assistente.processar_comando_texto(texto)
        print("Comando identificado:", comando)
        assistente.executar_acao(comando)
        output = self.held_stdout.getvalue()
        print(output)
        self.assertIn("Iniciando Liberação do Satélite", output)
    
    def test_comando_invalido(self):
        self._reset_stdout()
        texto = "Comando desconhecido"
        comando = assistente.processar_comando_texto(texto)
        if comando:
            assistente.executar_acao(comando)
        else:
            print("Nenhum comando válido foi identificado.")
        output = self.held_stdout.getvalue()
        print(output)
        self.assertIn("Nenhum comando válido", output)

if __name__ == '__main__':
    unittest.main()
