def executar():
    print("Iniciando Estágio 2")
